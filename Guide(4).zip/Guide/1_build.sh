#!/bin/bash

docker build -t very_mainnet:1.0.0 .