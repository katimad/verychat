#!/bin/bash
# 2_execute.sh — Start VERY Node
set -eu

cd "$(dirname "$0")"

if [ ! -f "key.json" ]; then
  echo "ERROR: key.json not found."
  echo 'Place key.json in Guide/ — format: { "key": "0x<private_key>" }'
  exit 1
fi

docker compose up -d
