#!/bin/bash
# 1_pull.sh — Pull VERY Node image
set -eu

cd "$(dirname "$0")"

echo "=== Pulling VERY Node image ==="
docker compose pull
