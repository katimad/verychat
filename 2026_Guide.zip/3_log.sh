#!/bin/bash
# 3_log.sh — Follow VERY Node logs
cd "$(dirname "$0")"
docker compose logs -f
