#!/bin/bash
docker compose logs -f