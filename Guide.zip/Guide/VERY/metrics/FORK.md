This repo has been forked from https://github.com/rcrowley/go-metrics at commit e181e09
